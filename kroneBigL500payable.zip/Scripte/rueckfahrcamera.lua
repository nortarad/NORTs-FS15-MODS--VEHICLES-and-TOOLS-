_=[[ R�ckfahrCamera by Bluebaby210

	Author: Bluebaby210    www.mod-portal.com
	Date 23/08/2012
	Version 1.0
							frei verwendbar - keine Erlaubnis notwendig
							keine �nderungen am Skript ohne meine Erlaubnis

Erm�glicht das Umschalten auf eine R�ckfahrcamera. Wenn ihr im Fahrzeug sitzt (Indoor) und r�ckw�rts fahrt, wird
automatisch die Camera aktiv, wenn ihr sie vorher aktiviert habt (input Binding angabe) NUM_KP_8. Wenn ihr steht, schaltet
sie wieder zur�ck.
-------------------------------------------------------------------
Eintr�ge in der Moddesc:
		<specialization name="rueckfahrcamera" className="rueckfahrcamera" filename="rueckfahrcamera.lua" />
		
VehiclesTypes:
			<specialization name="rueckfahrcamera" />

Texte:
		<text name="backcam">
			<de>R�ckfahrcamera aktiviert.</de>
			<en>Backcamera aktivate.</en>
		</text>
		
		<text name="rueckfahrcamera">
			<de>R�ckfahrcamera aktivieren</de>
			<en>Backcamera aktivate</en>
		</text>

		<text name="rueckfahrcamera_Back">
			<de>R�ckfahrcamera deaktivieren</de>
			<en>Backcamera deaktivate</en>
		</text>

InputBindings:
			<input name="rueckfahrcamera"  category="VEHICLE" key1="KEY_KP_8"    key2="" button="" device="0" mouse="" />

			
Zudem muss in der i3d eine Kamera erstellt werden, in den Hauptkompont vom Fahrzeug verschgoben werden und platziert werden,

In der XML sind folgende eintr�ge erforderlich:

	<rueckfahrcamera IndoorCameraIndex = "2"> 
		<camera index="40"/>
	</rueckfahrcamera>

Beim IndoorCameraIndex ist anzugeben, die wievielte Camera die indoor Camera ist, ihr k�nnt auch die Hauptcamkera angeben
aber dann braucht man ja keine R�ckfahrcamera...;)!
Standart, wenn ihr keinen Index angebt, wird Camera 2 als Indoor Camera erkannt!


]]
	
	
rueckfahrcamera = {};

function rueckfahrcamera.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Steerable, specializations) and SpecializationUtil.hasSpecialization(Motorized, specializations);
end;

function rueckfahrcamera:load(xmlFile)

	self.rueckfahrcamera = Utils.indexToObject(self.components, getXMLString(xmlFile, "vehicle.rueckfahrcamera.camera#index"));
	self.rueckfahrcameraIndex = Utils.getNoNil(getXMLInt(xmlFile, "vehicle.rueckfahrcamera.#IndoorCameraIndex"),2);
	
	self.rueckfahrcameraState = false;
	--print ("Rueckfahrcamera geladen");
end;
function rueckfahrcamera:delete()
end;
function rueckfahrcamera:mouseEvent(posX, posY, isDown, isUp, button)
end;
function rueckfahrcamera:keyEvent(unicode, sym, modifier, isDown)
end;
function rueckfahrcamera:update(dt)

	if self:getIsActiveForInput() then
		if InputBinding.hasEvent(InputBinding.rueckfahrcamera) then
			self.rueckfahrcameraState = (not self.rueckfahrcameraState);
		end;

		--if not self.cameras[self.camIndex].allowTranslation then
		if self.camIndex == self.rueckfahrcameraIndex then
			if self.reverseDriveSoundEnabled and self:getIsActiveForSound() then
				if self.rueckfahrcameraState == true then
					renderText(0.375, 0.92, 0.022, g_i18n:getText("backcam"));
					setCamera(self.rueckfahrcamera);
				elseif self.rueckfahrcameraState == false then
					renderText(0.375, 0.92, 0.022, "Sie koennen eine Rueckfahrcamera aktivieren");
				end;
			end;
		end;

	end;
end;
function rueckfahrcamera:updateTick(dt)
end;
function rueckfahrcamera:draw()	

	if self:getIsActive() then
		if self:getIsActiveForInput() then
			if self.rueckfahrcameraState == false then
			g_currentMission:addHelpButtonText(g_i18n:getText("rueckfahrcamera"), InputBinding.rueckfahrcamera);
			elseif self.rueckfahrcameraState == true then
			g_currentMission:addHelpButtonText(g_i18n:getText("rueckfahrcamera_Back"), InputBinding.rueckfahrcamera);
			end;
		end;
	end;

end;
