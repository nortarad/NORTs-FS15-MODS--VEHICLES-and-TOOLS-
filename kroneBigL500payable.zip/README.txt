Mod: KRONE BIG-L500 Pro

Modell: LS13:usxi7sd LS15:Jaison
Textur: Giants, Jaison
Ingame: LS15: Jaison

Alle inhalte unterliegen dem Uhrheberrecht des erstellers, ggf sind auch inhalte anderer enthalten und unterliegen somit dem Urheberrecht des inhabers von dem es erstellt wurde. 

Download inkl Link ist nur �ber Modhoster Erlaubt!

Dieser Mod darf ,ohne vorherige Genehmigung von uns, auf keinen anderen Seiten zum Download gestellt oder Ver�ffentlicht werden. Wir behalten uns das Recht vor alle Links oder Ver�ffentlichungen auf anderen Seiten entfernen zu lassen. Auch das ver�ffentlichen auf anderen Downloadportalen oder �hnlichen z�hlen zu den vorher genannten Punkten. S�mtliche Scripte d�rfen nicht frei verwendet werden, sofern keine Erlaubnis oder allgemeine Freigabe vom Autor vorhanden ist.

Wir berufen uns in allen F�llen auf das Urhebergesetz. Hier einige wichtige Paragraphen.

� 12 Ver�ffentlichungsrecht
(1) Der Urheber hat das Recht zu bestimmen, ob und wie sein Werk zu ver�ffentlichen ist.
(2) Dem Urheber ist es vorbehalten, den Inhalt seines Werkes �ffentlich mitzuteilen oder zu beschreiben, solange weder das Werk noch der wesentliche Inhalt oder eine Beschreibung des Werkes mit seiner Zustimmung ver�ffentlicht ist.

� 14 Entstellung des Werkes
Der Urheber hat das Recht, eine Entstellung oder eine andere Beeintr�chtigung seines Werkes zu verbieten, die geeignet ist, seine berechtigten geistigen oder pers�nlichen Interessen am Werk zu gef�hrden.

� 23 Bearbeitungen und Umgestaltungen
Bearbeitungen oder andere Umgestaltungen des Werkes d�rfen nur mit Einwilligung des Urhebers des bearbeiteten oder umgestalteten Werkes ver�ffentlicht oder verwertet werden. Handelt es sich um eine Verfilmung des Werkes, um die Ausf�hrung von Pl�nen und Entw�rfen eines Werkes der bildenden K�nste, um den Nachbau eines Werkes der Baukunst oder um die Bearbeitung oder Umgestaltung eines Datenbankwerkes, so bedarf bereits das Herstellen der Bearbeitung oder Umgestaltung der Einwilligung des Urhebers.

Quelle und weitere Gesetzesausz�ge: http://www.gesetze-im-internet.de/urhg/index.html

Wir bitten darum diese Gesetze einzuhalten, da sie mit diesem Hinweis rechtskr�ftig sind. 

________________________________________________________________________________________________________________________________________________________________

Mod: KRONE BIG-L500 Pro

Model: LS13: usxi7sd LS15: Jaison
Texture: Giants, Jaison
Ingame: LS15: Jaison

All contents are subject to Uhrheberrecht of the creator, possibly also contain other content and thus subject to the copyright of the proprietor of which it was created.

Download incl link is allowed only on Modhoster!

This mod may be, made without prior approval from us to any other sites to download or Published. We reserve the right to any links or publications to be removed on other sites. Also publish on other download portals or similar among the points previously mentioned. All scripts may not be used free unless permission by the author or general release is available.

We refer in all cases to the Copyright Act. Here are some important paragraphs.

� 12 Publication Law
(1) The author shall have the right to determine whether and how his work is to be published.
(2) The copyright is reserved to inform the content of his work publicly, or to describe, as long as neither the work nor the substance or a description of the work is published with his consent.

� 14 disfigurement of the work
The author has the right to prohibit any distortion or any other mutilation of his work, which is likely to jeopardize his legitimate intellectual or personal interests in the work.

� 23 edits and transformations
Changes or other modifications of the work may be published or used only with the consent of the author of processed or transformed plant. If it is a film adaptation of the work to the execution of plans and projects of a work of fine arts in order to demand the reconstruction of a work of architecture or to the adaptation or transformation of a database work already preparing the adaptation or transformation of the consent of the author.

Source and further laws Excerpts: http://www.gesetze-im-internet.de/urhg/index.html

We ask you to comply with these laws, as they are legally binding with this reference.

________________________________________________________________________________________________________________________________________________________________

Mod: KRONE BIG-L500 Pro

Modelis: LS13: usxi7sd LS15: Jaison
Tekstura: Giants, Jaison
Ingame: LS15: Jaison

Visi turinys gali buti Uhrheberrecht kurejo, galbut taip pat yra kitas turinys, todel atsi�velgiant i jo savininko, kurio ji buvo sukurta autoriu.

Parsisiusti isk nuoroda leid�iama tik Modhoster!

Tai mod galima, pagamintas be i�ankstinio pas mus jokiu kitu svetainiu atsisiusti arba paskelbta. Mes pasiliekamedas bet nuorodos ar leidiniuose teise pa�alinti kitose interneto svetainese. Taip pat skelbti kitose parsisiusti portalu ar pana�us tarp ta�ku anksciau paminetu. Visi scenarijai gali buti naudojamas nemokamai, nebent leidus autoriaus ar apskritai laida yra prieinama.

Kalbame apie visus atvejus, i Autoriu teisiu istatymo. �tai keletas svarbiu punktai.

� 12 Leidinys istatyma
(1)Der Autorius turi teise spresti, ar ir kaip jo darbas turi buti skelbiamas.
(2)Dem autoriu Rezervuotos vie�ai apie savo darba turini, arba apra�ant, kol neidas darbas, neider med�iaga areine Darbu skelbiama jo sutikimu.

� 14 subjaurojimas darbu
DerAutorius turi teise u�drausti bet kokio i�kraipymo ar kita �alojima savo darba, kuris gali pakenkti jo teisetiems intelektines ar asmeninius interesus darbe.

� 23 keitimus ir kintancias
Pokyciu ar kitu keisdama darbo, gali buti skelbiama arba naudojami tik su apdorotu arba transformuota augalo autoriaus sutikimo. Jei tai kino pritaikymas darbui su planu ir projektu vaiku dailes darbu atlikima, kad butu pareikalauti, kad butu architekturos ar i pritaikymas ar keitimas bazes darbu rekonstrukcija jau rengia pritaikymas ar keitimas ides sutikimo autorius.

�altinis ir toliau istatymai I�traukos: http://www.gesetze-im-internet.de/urhg/index.html

Mes pra�ome, kad butu laikomasi �iu istatymu, nes jie yra teisi�kai privalomos �ia nuoroda.

________________________________________________________________________________________________________________________________________________________________

Mod: KRONE BIG-Pro L500

Model LS13: usxi7sd LS15: Jaison
Tekstura: Giants, Jaison
W grze: LS15: Jaison

Wszystkie tresci sa objete Uhrheberrecht tw�rcy, ewentualnie takze zawierac inne materialy, a wiec podlega prawom autorskim wlasciciela, z kt�rych zostal utworzony.

Pobierz wew zwiazek jest dozwolony tylko na Modhoster!

Ten mod moze byc wykonane bez uprzedniej zgody od nas do innych stron, aby pobrac lub publikowane. Zastrzegamy sobie prawo do publikacji lub link�w do usuniecia na innych stronach. Publikuje takze na innych portalach lub podobny pobrania sposr�d punkt�w wymienionych powyzej. Wszystkie skrypty nie moga byc uzywane za darmo, chyba zgody przez autora lub og�lne wydanie jest dostepne.

Odwolujemy sie w kazdym przypadku do ustawy o prawie autorskim. Oto kilka waznych ust.

� 12 Prawo publikacji
(1),Der tw�rcy przysluguje prawo do okreslenia, czy iw jaki spos�b jego praca ma byc opublikowana.
(2) Prawa autorskie zastrzezone jest poinformowac tresc swojej pracy publicznie, lub opisac, tak dlugo, jak niedas praca, anider substancji lubeine opis prac zostala opublikowana za jego zgoda.

� 14 znieksztalcenia prac
Autor ma prawo do zakazania wszelkich zakl�cen lub innego okaleczenia jego pracy, kt�ra moze zagrozic jego uzasadnionych interes�w intelektualnej lub osobistych w pracy.

� 23 zmiany i transformacje
Zmiany lub inne modyfikacje prac moga byc publikowane lub wykorzystywane jedynie za zgoda autora zakladu poddany obr�bce lub przetworzeniu. Jesli jest to filmowa adaptacja dziela do realizacji plan�w i projekt�w dzielo sztuki, aby zadac rekonstrukcje dziela architektury lub do adaptacji lub przeksztalcenia pracy bazy danych juz przygotowuje adaptacje lub transformacji zgodydes autor.

Zr�dlo i dalsze przepisy Fragmenty: http://www.gesetze-im-internet.de/urhg/index.html

Prosimy o dostosowanie sie do tych przepis�w, poniewaz sa one prawnie wiazace w tej publikacji.